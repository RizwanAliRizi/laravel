<?php $__env->startSection('content'); ?>
    <h3>Roles</h3>
    <a class="btn btn-success" href="<?php echo e(route('role.create')); ?>"> Create Role</a>
    <table class="table">
        <tr>
            <th>Name</th>
            <th>Display Name</th>
            <th>Description</th>
            <th>Action</th>
        </tr>

        <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($role->name); ?></td>
                <td><?php echo e($role->display_name); ?></td>
                <td><?php echo e($role->description); ?></td>
                <td>
                    <a class="btn btn-info btn-sm" href="<?php echo e(route('role.edit',$role->id)); ?>">Edit</a>
                    <form action="<?php echo e(route('role.destroy',$role->id)); ?>"  method="POST">
                       <?php echo e(csrf_field()); ?>

                       <?php echo e(method_field('DELETE')); ?>

                       <input class="btn btn-sm btn-danger" type="submit" value="Delete">
                     </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td>No roles</td>
            </tr>
            <?php endif; ?>

    </table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>