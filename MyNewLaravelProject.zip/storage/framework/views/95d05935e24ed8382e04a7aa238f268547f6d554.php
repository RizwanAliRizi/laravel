<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"> Assign Role For <?php echo e($name); ?> </div>

                <div class="card-body">
                    <form action="<?php echo e(url('AssigningRolesPermissions',$name)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col col-md-6">  <h1> Permissions </h1>
                    <ul>
                  <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <input type="checkbox" name="permissions[]" value="<?php echo e($permission->name); ?>" checked><?php echo e($permission->name); ?><br>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </ul>
               </div>
                         <div class="col col-md-6">
                             
                             <h1>Roles</h1>
                    <ul>
                  <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <input type="checkbox" name="roles[]" value="<?php echo e($role->name); ?>" checked><?php echo e($role->name); ?><br>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </ul>

                         </div>
                    </div>
                    <div class="row justify-content-center">
                <button class="btn btn-success" style="width: 50%" type="submit">Submit</button>
            </div>
</form>
                  
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>