<?php $__env->startSection('main'); ?>
<!-- <div class="row">
<div class="col-sm-12">
    <h1 class="display-3">Products</h1>
  <table class="table table-striped">
    <thead>
        <tr>
          <td>ID</td>
          <td>ProductName</td>
          <td>ProductPrice</td>
          <td>Category</td>
          <td>AttchedFile</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $all_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
           <td> <?php echo e($product->id); ?></td>
            <td><?php echo e($product->name); ?></td>
            <td><?php echo e($product->price); ?></td>
            <td>
            <?php $__currentLoopData = $product->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php $name = App\Category::find($productCategory->pivot->category_id)->title; ?>
             <?php echo e($name); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td><img style="width: 10%;height: 20%" src="/storage/myfile/<?php echo e($product->file); ?>"></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<div>
</div>
 -->

 <?php $__currentLoopData = $all_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <div class="row">
<div class="card" style="width: 15rem; margin: 30px">
  <img class="card-img-top" style="width: 100%;height: 50%" src="/storage/myfile/<?php echo e($product->file); ?>" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title"><h3>Name: <?php echo e($product->name); ?> </h3></h5>

   <h7><h4>Price: <?php echo e($product->price); ?></h4></h7>

   <h4> Category: </h4>
   <?php $__currentLoopData = $product->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <?php $name = App\Category::find($productCategory->pivot->category_id)->title; ?>
   <h7> <?php echo e($name); ?>,
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </h7>
    <a style="margin: 20px" href="#" class="btn btn-primary">Go somewhere</a>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>