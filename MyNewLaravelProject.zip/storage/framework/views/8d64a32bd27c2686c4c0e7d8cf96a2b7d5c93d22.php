<?php $__env->startSection('main'); ?>
<div class="row">
 <div class="col-sm-8 offset-sm-2">
    <h1 class="display-3">Customers</h1>
  <div>
  <?php if(session('message')): ?>
<div class="alert alert-danger" ><?php echo e(session('message')); ?> </div> 

  <?php endif; ?>

  <?php if(session('saveEmployee')): ?>

  <div class="alert alert-success" ><?php echo e(session('saveEmployee')); ?> </div> 

  <?php endif; ?>

    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div><br />
    <?php endif; ?>
      <form method="post" action="<?php echo e(route('savingData')); ?>">
          <?php echo csrf_field(); ?>
          <div class="form-group">    
              <label for="customer_name">Name:</label>
              <input type="text" class="form-control" name="customer_name"/>
          </div>

          <div class="form-group">
              <label for="age">Age:</label>
              <input type="number" class="form-control" name="age"/>
          </div>

          <div class="form-group">
            <select name="company_id" class="form-control" >
  
             <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <option value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>

             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

          </div>
                
          <button type="submit" class="btn btn-primary-outline">Add customer</button>
          <a href="<?php echo e(route('allcustomer')); ?>" class="btn-primary-outline">
          Show Customers</a>

      </form>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>