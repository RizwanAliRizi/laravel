<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet" type="text/css">

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }

            @media  screen and (max-width: 950px){
                #container{
                    width: 100%;
                }
                #button{
                    width: 100%;
                    padding: 15px;
                    margin: 5px;

                }
            }

            @media  screen and (max-width: 700){

                #button{
                    width:50%;

                }
            }
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>
                        <a href="<?php echo e(route('register')); ?>">Register</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="content">
                <div class="title m-b-md">
                    WELCOME
                </div>
               
                   <div id="container">
                      <a class="btn btn-info" id="button" href="<?php echo e(route('register_company')); ?>">Register company</a>
         

                
                     <a class="btn btn-info" id="button" href="<?php echo e(route('register_customer')); ?>">Register customer</a>

              
                     <a class="btn btn-info" id="button" href="<?php echo e(route('product_form')); ?>">Create Product</a>
      

                     <a class="btn btn-info" id="button" href="<?php echo e(url('assign_role')); ?>">Assign Role</a>
                

                       <!--   <a class="btn btn-info

                         " href="<?php echo e(url('grant_permission')); ?>" id="button">Grant Permissions</a> -->
                   </div>

            </div>
        </div>
    </body>
</html>
