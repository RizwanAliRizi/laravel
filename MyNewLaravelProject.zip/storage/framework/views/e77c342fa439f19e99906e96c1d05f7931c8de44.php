<?php $__env->startSection('content'); ?>
    <h3>Create Roles</h3>

    <form action="<?php echo e(route('role.store')); ?>" method="post" role="form">
        <?php echo e(csrf_field()); ?>


    	<div class="form-group">
    		<label for="name">Name of role</label>
    		<input type="text" class="form-control" name="name" id="" placeholder="Name of role">
    	</div>
        <div class="form-group">
    		<label for="display_name">Display name</label>
    		<input type="text" class="form-control" name="display_name" id="" placeholder="Display name">
    	</div>
        <div class="form-group">
    		<label for="description">Description</label>
    		<input type="text" class="form-control" name="description" id="" placeholder="Description">
    	</div>

		
			
			
		

        <div class="form-group text-left">
            <h3>Permissions</h3>
            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		<input type="checkbox"   name="permission[]" value="<?php echo e($permission->id); ?>" > <?php echo e($permission->name); ?> <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	</div>






    	<button type="submit" class="btn btn-primary">Submit</button>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>