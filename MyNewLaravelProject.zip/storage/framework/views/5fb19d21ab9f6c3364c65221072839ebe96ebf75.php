<?php $__env->startSection('main'); ?>



<div class="row">
<div class="col-sm-12">
    <h1 class="display-3">Customers</h1>    
  <table class="table table-striped">
    <thead>
        <tr>
          <td>ID</td>
          <td>Name</td>
          <td>Age</td>
          <td>CompanyName</td>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td> <?php echo e($customerDetail->id); ?></a>
            <td><?php echo e($customerDetail->name); ?></td>
            <td><?php echo e($customerDetail->age); ?></td>
            <td> <?php echo e($company_name); ?>

        </tr>
  
    </tbody>
  </table>
<div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>