<?php $__env->startSection('main'); ?>
<style type="text/css">
  
   table.table td a.edit {
        color: #FFC107;
    }
    table.table td a.delete {
        color: #E34724;
    }
</style>

<div class="row">
<div class="col-sm-12">
    <h1 class="display-3">Employees</h1> 

    <?php if(session('updateCustomer')): ?>
    <div class="alert alert-success"><?php echo e(session('updateCustomer')); ?></div>
    <?php endif; ?>   

     <?php if(session('deleteCutomer')): ?>
    <div class="alert alert-success"><?php echo e(session('deleteCutomer')); ?></div>
    <?php endif; ?>   
  <table class="table table-striped">
    <thead>
        <tr>
          <td>ID</td>
          <td>Name</td>
          <td>Age</td>
          <td>CompanyName</td>
          <td>Action </td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $all_customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td> <?php echo e($customer->id); ?></td>
            <td><?php echo e($customer->name); ?></td>
            <td><?php echo e($customer->age); ?></td>
             <td><?php echo e($customer->company->name); ?></td>
             <td>

              <a class="edit" title="Edit" data-toggle="tooltip" href="<?php echo e(route ('edit_cutomer',$customer->id)); ?>" ><i class="material-icons">&#xE254;</i></a>
    
              <a class="delete" title="Delete" data-toggle="tooltip" href="<?php echo e(url ('deleteCutomer',$customer->id)); ?>"><i class="material-icons">&#xE872;</i></a>

           </td>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>